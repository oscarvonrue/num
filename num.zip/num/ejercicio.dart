import 'dart:io';
import 'dart:math';

void main() {

  Random random = Random();
  int numeroSecreto = random.nextInt(100) + 1;

  print("Adivina el número entre 1 y 100");
  print("Tienes 3 intentos para acertar");

  int intentos = 0;
  const maxIntentos = 3;

  while (intentos < maxIntentos) {
  
    print("Ingrese un número (Intento ${intentos + 1} de $maxIntentos): ");
    String input = stdin.readLineSync();

 
    int numeroIngresado;
    try {
      numeroIngresado = int.parse(input);
    } catch (e) {
      print("Por favor, ingrese un número válido");
      continue;
    }

  if (numeroIngresado < numeroSecreto) {
    print("El número que ingresaste es menor que el número secreto");
    } else if (numeroIngresado > numeroSecreto) {
      print("El número que ingresaste es mayor que el número secreto");
      } else {
        print("¡Felicidades! Acertaste el número secreto");
        break;
        }
        intentos++;
        }
        if (intentos == maxIntentos) {
          print("Lo siento, has agotado todos tus intentos. El número secreto
          era $numeroSecreto");
          }
          }